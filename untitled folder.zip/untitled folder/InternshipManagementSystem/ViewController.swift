//
//  ViewController.swift
//  InternshipManagementSystem
//
//  Created by Student on 5/26/22.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        print("test")
    }


}

